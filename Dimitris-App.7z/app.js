const express = require('express');
const path = require('path');
const hbs = require('hbs');
const axios = require('axios');


const app = express();
const port = process.env.PORT || 3000;
console.log(process.env.PORT);

const publicDirectoryPath = path.join(__dirname, './public');
const viewsPath = path.join(__dirname, './views');

app.set('view engine', 'hbs');
app.set('views', viewsPath);
app.use(express.static(publicDirectoryPath));

app.get('', (req, res) => {
  res.render('index');
});

app.get('/forecast', (req, res) => {
  res.render('forecast');
});

app.get('/get_data', (req, res) => {

  var d = new Date();
  currentHours = d.getHours();
  currentHours = ("0" + currentHours).slice(-2); //όλες οι τιμές έτσι σε διπλά ψηφία
  currentMinutes = d.getMinutes();
  currentMinutes = ("0" + currentMinutes).slice(-2);//γιατί αλλιώς τα βγάζει μονά
  currentMonth = d.getMonth()+1;
  currentMonth = ("0" + currentMonth).slice(-2);//και γίνεται λάθος κλήση
  currentDate = d.getDate();
  currentDate = ("0" + currentDate).slice(-2);
  currentHour18 = '18';
  currentMinute='00';
  console.log(req.query.latitude);
  console.log(req.query.longitude);

  const url = 'https://global-weather.pp.ua/api/v1/forecast/'+req.query.latitude+';'+req.query.longitude+'/'+
  d.getFullYear()+currentMonth+currentDate+currentHours+currentMinutes+'';


  axios
    .get(url)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });

 
});

app.get('/get_data', (req, res) => {

  var d18 = new Date();
  currentMonth = d.getMonth()+1;
  currentMonth = ("0" + currentMonth).slice(-2);//και γίνεται λάθος κλήση
  currentDate = d.getDate();
  currentDate = ("0" + currentDate).slice(-2);
  currentHour18 = '18';
  currentMinute='00';
  console.log(req.query.latitude);
  console.log(req.query.longitude);


  const url_18= 'https://global-weather.pp.ua/api/v1/forecast/'+req.query.latitude+';'+req.query.longitude+'/'+
  d.getFullYear()+currentMonth+currentDate+currentHour+currentMinute+'';
  
    axios
    .get(url_18)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

app.listen(port, () => {
  console.log(`Server is up on port ${port}.`);
});
