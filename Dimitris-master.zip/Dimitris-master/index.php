<?php
// Θωμάς - metar.gr


error_reporting(0);

$images = glob("snap/{*.jpg}", GLOB_BRACE);

array_multisort(array_map( 'filemtime', $images ),SORT_NUMERIC,SORT_DESC,$images);

$time_del = "7000"; // Οι εικόνες που θέλουμε να μένουν στον φάκελο.
if(count($images)){
for( $i=0 ; $i < count($images) ; $i++ ){
if ($i > $time_del) {unlink($images[$i]);}
}}

//$timeweather = filemtime("../../ormylia/camera.php");
//if ($timeweather < (time() - 1200)) {$data = "  |  The weather station is offline";} 
//else {
//include "../../diavata/camera.php";
//$data = "  | $outsideTemp | $outsideHumidity | $windSpeed  $windDirection | $dailyRain | $rainRate";
//}

// ΠΡΟΒΟΛΗ ΕΙΚΟΝΑΣ
header("Content-Type: image/jpeg");
$filesize = filesize($images[1]);
if ($filesize < 10000) {unlink($images[1]);}
$filemtime = filemtime($images[1]);
$date = date("d/m/Y  |  H:i:s",$filemtime);
$ena = imagecreatefromjpeg($images[1]);
$dyo = imagecreatefrompng("meteohellas.png");
imagecopy($ena, $dyo, 0, 0, 0, 0, 2688, 1520);
$white = imagecolorallocate($ena, 255, 255, 255);
$black = imagecolorallocate($ena, 0, 0, 0);
$font = imageloadfont('../HomBold_16x24_LE.gdf');
imagestring($ena, $font, 16, 14, "$date  |  Ikaria |  East Aegean  |  Greece$data", $white);


// ΜΕΤΑ ΑΠΟ 10 ΛΕΠΤΑ OFFLINE
if ($filemtime < (time() - 1200)) {
$font = imageloadfont('../04b.gdf');
imagestring($ena, 5, 501, 361, "WE WILL SOON BE ONLINE, THE METEO-HELLAS.COM TEAM", $black);
imagestring($ena, 5, 500, 360, "WE WILL SOON BE ONLINE, THE METEO-HELLAS.COM TEAM", $white);}
// ΜΕΤΑ ΑΠΟ 10 ΛΕΠΤΑ OFFLINE

imagejpeg($ena);
imagedestroy($ena);
imagedestroy($dyo);
// ΠΡΟΒΟΛΗ ΕΙΚΟΝΑΣ

// Θωμάς - metar.gr
?>