const express = require('express');
const path = require('path');
const hbs = require('hbs');
const axios = require('axios');

const app = express();
const port = process.env.PORT || 3000;
console.log(process.env.PORT);

const publicDirectoryPath = path.join(__dirname, './public');
const viewsPath = path.join(__dirname, './views');

app.set('view engine', 'hbs');
app.set('views', viewsPath);
app.use(express.static(publicDirectoryPath));

// Κεντρική Σελίδα
app.get('', (req, res) => {
  res.render('index');
});

// Σημερινές Προβλέψεις
app.get('/forecast', (req, res) => {
  res.render('forecast');
});


// Ημερήσιες Προβλέψεις
app.get('/dailyforecast', (req, res) => {
  res.render('dailyforecast');
});

// Ημερήσιες Προβλέψεις
app.get('/cameras', (req, res) => {
  res.render('cameras');
});


//---------------------------------------Τρέχουσες Συνθήκες-----------------------------------------------------------------------
app.get('/get_data', (req, res) => {
  var d = new Date();
  currentHours = d.getHours();
  currentHours = ('0' + currentHours).slice(-2); //όλες οι τιμές έτσι σε διπλά ψηφία
  currentMinutes = d.getMinutes();
  currentMinutes = ('0' + currentMinutes).slice(-2); //γιατί αλλιώς τα βγάζει μονά
  currentMonth = d.getMonth() + 1;
  currentMonth = ('0' + currentMonth).slice(-2); //και γίνεται λάθος κλήση
  currentDate = d.getDate();
  currentDate = ('0' + currentDate).slice(-2);
  currentHour18 = '18';
  currentMinute = '00';
  console.log(req.query.latitude);
  console.log(req.query.longitude);

  const url =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' 
    + d.getFullYear() + currentMonth + currentDate + currentHours + currentMinutes + '';

  axios
    .get(url)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------06:00--------------------------------------------------------------------------------------
app.get('/get_forecast06', (req, res) => {
  var d06 = new Date();
  currentMonth = d06.getMonth() + 1;
  currentMonth = ('0' + currentMonth).slice(-2); //και γίνεται λάθος κλήση
  currentDate = d06.getDate();
  currentDate = ('0' + currentDate).slice(-2);
  console.log(req.query.latitude);
  console.log(req.query.longitude);

  const url_06 =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + d06.getFullYear() 
    + currentMonth + currentDate + '06' + '00' + '';

  axios
    .get(url_06)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------12:00--------------------------------------------------------------------------------------
app.get('/get_forecast12', (req, res) => {
  var d12 = new Date();
  currentMonth = d12.getMonth() + 1;
  currentMonth = ('0' + currentMonth).slice(-2); //και γίνεται λάθος κλήση
  currentDate = d12.getDate();
  currentDate = ('0' + currentDate).slice(-2);
  //currentHour12 = '12';
  //currentMinute = '00';
  console.log(req.query.latitude);
  console.log(req.query.longitude);

  const url_12 =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + d12.getFullYear() 
    + currentMonth + currentDate + '12' + '00' + '';

  axios
    .get(url_12)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});


//---------------------------------------18:00--------------------------------------------------------------------------------------

app.get('/get_forecast', (req, res) => {
  var d18 = new Date();
  currentMonth = d18.getMonth() + 1;
  currentMonth = ('0' + currentMonth).slice(-2); //και γίνεται λάθος κλήση
  currentDate = d18.getDate();
  currentDate = ('0' + currentDate).slice(-2);
  currentHour18 = '18';
  currentMinute = '00';
  console.log(req.query.latitude);
  console.log(req.query.longitude);

  const url_18 =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + d18.getFullYear() 
    + currentMonth + currentDate + currentHour18 + currentMinute + '';

  axios
    .get(url_18)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------24:00--------------------------------------------------------------------------------------

app.get('/get_forecast24', (req, res) => {
  var d24 = new Date();
  currentMonth = d24.getMonth() + 1;
  currentMonth = ('0' + currentMonth).slice(-2); //και γίνεται λάθος κλήση
  currentDate = d24.getDate();
  currentDate = ('0' + currentDate).slice(-2);
  console.log(req.query.latitude);
  console.log(req.query.longitude);

  const url_24 =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + d24.getFullYear() 
    + currentMonth + currentDate + '24' + '00' + '';

  axios
    .get(url_24)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//--------------------------------------- Αύριο το μεσημέρι -------------------------------------------------------------------------

app.get('/get_forecasttm', (req, res) => {
 //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 86400000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  const url_tm =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '12'+'00';

  axios
    .get(url_tm)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------Αύριο μεσάνυχτα----------------------------------------------------------------------

app.get('/get_forecastat', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 86400000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  const url_at =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '24'+'00';

  axios
    .get(url_at)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------Μεθαύριο το μεσημέρι---------------------------------------------------------------

app.get('/get_forecastafter', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 172800000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_after =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '12'+'00';

  axios
    .get(url_after)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------Μεθαύριο τα μεσάνυχτα---------------------------------------------------------------

app.get('/get_forecastaftermidnight', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 172800000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_afterMidnight =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '24'+'00';

  axios
    .get(url_afterMidnight)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

 //---------------------------------------3η Μέρα Μεσημέρι---------------------------------------------------------------

app.get('/get_forecast3rdMid', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 259200000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_3rdMid =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '12'+'00';

  axios
    .get(url_3rdMid)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------3η Μέρα  μεσάνυχτα---------------------------------------------------------------

app.get('/get_forecast3rdmidnight', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 259200000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_3rdMidnight =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '24'+'00';

  axios
    .get(url_3rdMidnight)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------4η Μέρα Μεσημέρι---------------------------------------------------------------

app.get('/get_forecast4thMid', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 345600000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_4thMid =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '12'+'00';

  axios
    .get(url_4thMid)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------4η Μέρα  μεσάνυχτα---------------------------------------------------------------

app.get('/get_forecast4thmidnight', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 345600000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_4thMidnight =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '24'+'00';

  axios
    .get(url_4thMidnight)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------5η Μέρα---------------------------------------------------------------

app.get('/get_forecast5th', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 432000000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_5th =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '12'+'00';

  axios
    .get(url_5th)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------6η Μέρα---------------------------------------------------------------

app.get('/get_forecast6th', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 518400000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_6th =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '12'+'00';

  axios
    .get(url_6th)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------7η Μέρα---------------------------------------------------------------

app.get('/get_forecast7th', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 604800000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_7th =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '12'+'00';

  axios
    .get(url_7th)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});

//---------------------------------------8η Μέρα---------------------------------------------------------------

app.get('/get_forecast8th', (req, res) => {
  //Υπολογισμός για το αύριο. 86400 * 1000 * 3  Each day is 86400 seconds 
  var dateObj = new Date(); 
  var val = dateObj.getTime(); 
  var day = 691200000; 
  month = dateObj.getMonth()+1;
  month = ('0' + month).slice(-2); 
  val = val + day; 
  dateObj = new Date(val); // ********important*********
  val =dateObj.getFullYear()+ month +  dateObj.getDate();
  console.log(req.query.latitude);
  console.log(req.query.longitude);
  
  const url_8th =
    'https://global-weather.pp.ua/api/v1/forecast/' + req.query.latitude + ';' + req.query.longitude + '/' + val + '12'+'00';

  axios
    .get(url_8th)
    .then(result => {
      res.send(result.data);
    })
    .catch(err => {
      console.log(err);
    });
});




//--------------------------------------- Server is UP! ---------------------------------------------------------------
app.listen(port, () => {
  console.log(`Server is up on port ${port}.`);
});

